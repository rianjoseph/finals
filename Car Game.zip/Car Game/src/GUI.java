import java.awt.*;
import java.awt.event.*;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import javax.swing.*;

public class GUI {

    JFrame frame;
    JPanel panel;
    JPanel obstacle1;
    JPanel obstacle2;
    control control;
    RoadPanel roadPanel;  
    JLabel gameOverLabel;
    JButton restartButton;

    Timer obstacleTimer;
    Timer roadTimer;
    Timer difficultyTimer;

    int roadY = 0; 
    int speed = 10;

    int obstacle1Speed = 6;
    int obstacle2Speed = 9;
    int roadSpeed = 6;
    int difficultyTimerInterval = 5000; // 5 seconds
    int level = 1;

    JLabel levelLabel;

    public GUI() {
        control = new control(this);
        initGUI();
    }

    private void initGUI() {
        frame = new JFrame("2D CAR GAME");
        frame.setLayout(null);

        roadPanel = new RoadPanel();
        roadPanel.setBounds(0, 0, 600, 783);
        roadPanel.setLayout(null);

        panel = new JPanel();
        panel.setSize(50, 150);
        JLabel car = new JLabel(new ImageIcon("car.png"));
        panel.add(car);
        panel.setLocation(270, 600);
        panel.setBackground(Color.BLACK);

        ImageIcon obstacleCarIcon = rotateIcon(new ImageIcon("car.png"), 180);

        obstacle1 = new JPanel();
        obstacle1.setSize(50, 150);
        JLabel car1 = new JLabel(obstacleCarIcon);
        obstacle1.add(car1);
        obstacle1.setLocation(150, -200);
        obstacle1.setBackground(Color.BLACK);

        obstacle2 = new JPanel();
        obstacle2.setSize(50, 150);
        JLabel car2 = new JLabel(obstacleCarIcon);
        obstacle2.add(car2);
        obstacle2.setLocation(400, -500);
        obstacle2.setBackground(Color.BLACK);

        gameOverLabel = new JLabel("GAME OVER");
        gameOverLabel.setFont(new Font("Arial", Font.BOLD, 40));
        gameOverLabel.setForeground(Color.BLACK);
        gameOverLabel.setBounds(150, 300, 300, 50);
        gameOverLabel.setVisible(false);

        restartButton = new JButton("Restart");
        restartButton.setBounds(225, 370, 150, 40);
        restartButton.setFont(new Font("Arial", Font.BOLD, 20));
        restartButton.setVisible(false);
        restartButton.addActionListener((ActionEvent e) -> restartGame());

        levelLabel = new JLabel("Level: 1");
        levelLabel.setFont(new Font("Arial", Font.BOLD, 20));
        levelLabel.setForeground(Color.WHITE);
        levelLabel.setBounds(10, 10, 150, 30);

        roadPanel.add(panel);
        roadPanel.add(obstacle1);
        roadPanel.add(obstacle2);
        roadPanel.add(gameOverLabel);
        roadPanel.add(restartButton);
        roadPanel.add(levelLabel);

        frame.add(roadPanel);
        frame.setSize(600, 800);
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
        frame.setResizable(false);
        frame.addKeyListener(control);
        frame.setFocusable(true);
        frame.requestFocusInWindow();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        startRoadMovement();
        startObstacleMovement();
        startDifficultyIncrease();
    }

    private void startRoadMovement() {
        roadTimer = new Timer(30, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                roadY += roadSpeed;
                if (roadY >= 783) {
                    roadY = 0;
                }
                roadPanel.repaint();
            }
        });
        roadTimer.start();
    }

    private void startObstacleMovement() {
        obstacleTimer = new Timer(30, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                moveObstacle(obstacle1, obstacle1Speed);
                moveObstacle(obstacle2, obstacle2Speed);
                checkCollision();
            }
        });
        obstacleTimer.start();
    }

    private void startDifficultyIncrease() {
        difficultyTimer = new Timer(difficultyTimerInterval, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (obstacle1Speed < 20) { // optional max speed
                    obstacle1Speed++;
                    obstacle2Speed++;
                    roadSpeed++;
                    level++;
                    levelLabel.setText("Level: " + level);
                }
            }
        });
        difficultyTimer.start();
    }

    private void moveObstacle(JPanel obs, int speed) {
        int x = obs.getX();
        int y = obs.getY();

        if (y > 800) {
            int randomX = 50 + (int) (Math.random() * 450);
            obs.setLocation(randomX, -150);
        } else {
            obs.setLocation(x, y + speed);
        }
    }

    private void checkCollision() {
        Rectangle playerBounds = panel.getBounds();
        Rectangle obs1Bounds = obstacle1.getBounds();
        Rectangle obs2Bounds = obstacle2.getBounds();

        if (playerBounds.intersects(obs1Bounds) || playerBounds.intersects(obs2Bounds)) {
            gameOver();
        }
    }

    private void gameOver() {
        JOptionPane.showMessageDialog(panel, "Game Over", "Sheesh!", JOptionPane.INFORMATION_MESSAGE);
        obstacleTimer.stop();
        roadTimer.stop();
        if (difficultyTimer != null) difficultyTimer.stop();

        gameOverLabel.setVisible(true);
        restartButton.setVisible(true);
        frame.removeKeyListener(control);
    }

    private void restartGame() {
        panel.setLocation(270, 600);
        obstacle1.setLocation(150, -200);
        obstacle2.setLocation(400, -500);

        gameOverLabel.setVisible(false);
        restartButton.setVisible(false);

        obstacle1Speed = 6;
        obstacle2Speed = 9;
        roadSpeed = 6;
        level = 1;
        levelLabel.setText("Level: 1");

        if (difficultyTimer != null) difficultyTimer.stop();
        if (roadTimer != null) roadTimer.stop();
        if (obstacleTimer != null) obstacleTimer.stop();

        frame.removeKeyListener(control);
        control = new control(this);
        frame.addKeyListener(control);
        frame.requestFocusInWindow();

        startRoadMovement();
        startObstacleMovement();
        startDifficultyIncrease();
    }

    private ImageIcon rotateIcon(ImageIcon icon, double degrees) {
        Image img = icon.getImage();
        int w = img.getWidth(null);
        int h = img.getHeight(null);

        BufferedImage rotated = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = rotated.createGraphics();

        AffineTransform at = new AffineTransform();
        at.rotate(Math.toRadians(degrees), w / 2.0, h / 2.0);
        g2d.setTransform(at);
        g2d.drawImage(img, 0, 0, null);
        g2d.dispose();

        return new ImageIcon(rotated);
    }

    class RoadPanel extends JPanel {
        int lineWidth = 4;
        int lineLength = 30;
        int lineSpacing = 30;
        int laneDistance = 140;

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            int width = getWidth();
            int height = getHeight();

            g.setColor(Color.BLACK);
            g.fillRect(0, 0, width, height);

            int centerX = width / 2;

            g.setColor(Color.WHITE);

            for (int y = -lineLength + (roadY % (lineLength + lineSpacing)); y < height; y += (lineLength + lineSpacing)) {
                g.fillRect(centerX - lineWidth / 2, y, lineWidth, lineLength);
            }

            g.fillRect(centerX - laneDistance, 0, lineWidth, height);
            g.fillRect(centerX + laneDistance, 0, lineWidth, height);
        }
    }

    class control implements KeyListener {
        GUI game;

        public control(GUI game) {
            this.game = game;
        }

        @Override
        public void keyTyped(KeyEvent e) {}

        @Override
        public void keyPressed(KeyEvent e) {
            int pressed = e.getKeyCode();
            int a = game.panel.getX();
            int b = game.panel.getY();

            if (pressed == KeyEvent.VK_LEFT && a - game.speed >= 0) {
                game.panel.setLocation(a - game.speed, b);
            } else if (pressed == KeyEvent.VK_RIGHT && a + game.speed + game.panel.getWidth() <= game.frame.getWidth()) {
                game.panel.setLocation(a + game.speed, b);
            }
        }

        @Override
        public void keyReleased(KeyEvent e) {}
    }

    public static void main(String[] args) {
        GUI gui = new GUI();
    }
}
