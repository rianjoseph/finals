import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class control implements KeyListener {

    GUI game;

    public control(GUI game) {
        this.game = game;
    }

    @Override
    public void keyTyped(KeyEvent e) {
        // Not used
    }

    @Override
    public void keyPressed(KeyEvent e) {
        int pressed = e.getKeyCode();

        if (pressed == KeyEvent.VK_LEFT) {
            // Move car left, but not beyond left edge (x >= 0)
            int x = game.panel.getX();
            int y = game.panel.getY();

            if (x - game.speed >= 0) {
                game.panel.setLocation(x - game.speed, y);
            } else {
                game.panel.setLocation(0, y);
            }

        } else if (pressed == KeyEvent.VK_RIGHT) {
            // Move car right, but not beyond right edge of frame
            int x = game.panel.getX();
            int y = game.panel.getY();

            int frameWidth = game.frame.getContentPane().getWidth();
            int carWidth = game.panel.getWidth();

            if (x + game.speed + carWidth <= frameWidth) {
                game.panel.setLocation(x + game.speed, y);
            } else {
                game.panel.setLocation(frameWidth - carWidth, y);
            }
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        // Not used
    }
}
